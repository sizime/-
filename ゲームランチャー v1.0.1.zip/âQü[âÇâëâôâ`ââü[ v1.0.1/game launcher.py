import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk
import subprocess
import os
import json

# データファイルのパス
DATA_FILE = 'games.json'

def load_games():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'r') as file:
            return json.load(file)
    return {}

def save_games(games):
    with open(DATA_FILE, 'w') as file:
        json.dump(games, file, indent=4)

def add_game():
    file_path = filedialog.askopenfilename(filetypes=[("Executable files", "*.exe")])
    if file_path:
        game_name = os.path.basename(file_path)
        games = load_games()
        if game_name in games:
            messagebox.showwarning("警告", "このゲームはすでにリストに存在します。")
        else:
            games[game_name] = {'path': file_path}
            save_games(games)
            update_game_list()
            messagebox.showinfo("成功", "ゲームが追加されました。")

def launch_game(event=None):
    selected_game = game_listbox.get(tk.ACTIVE)
    if selected_game:
        games = load_games()
        game_path = games.get(selected_game, {}).get('path')
        if game_path and os.path.exists(game_path):
            subprocess.Popen([game_path])
        else:
            messagebox.showerror("エラー", "指定されたゲームの実行ファイルが見つかりません。")
    else:
        messagebox.showerror("エラー", "ゲームが選択されていません。")

def update_game_list():
    game_listbox.delete(0, tk.END)
    games = load_games()
    for game_name in games.keys():
        game_listbox.insert(tk.END, game_name)

def change_game_name():
    selected_game = game_listbox.get(tk.ACTIVE)
    if selected_game:
        new_name = simpledialog.askstring("ゲーム名変更", f"新しいゲーム名を入力してください（現在のゲーム名：{selected_game}）:")
        if new_name:
            games = load_games()
            if new_name in games:
                messagebox.showwarning("警告", "このゲーム名はすでにリストに存在します。")
            else:
                games[new_name] = games.pop(selected_game)
                save_games(games)
                update_game_list()
                messagebox.showinfo("成功", "ゲーム名が変更されました。")
    else:
        messagebox.showerror("エラー", "ゲームが選択されていません。")

def delete_game():
    selected_game = game_listbox.get(tk.ACTIVE)
    if selected_game:
        games = load_games()
        if selected_game in games:
            del games[selected_game]
            save_games(games)
            update_game_list()
            messagebox.showinfo("成功", "ゲームが削除されました。")
        else:
            messagebox.showerror("エラー", "指定されたゲームがリストに存在しません。")
    else:
        messagebox.showerror("エラー", "ゲームが選択されていません。")

def open_file_location():
    selected_game = game_listbox.get(tk.ACTIVE)
    if selected_game:
        games = load_games()
        game_path = games.get(selected_game, {}).get('path')
        if game_path and os.path.exists(game_path):
            subprocess.Popen(['explorer', '/select,', os.path.abspath(game_path)])
        else:
            messagebox.showerror("エラー", "指定されたゲームのファイル場所が見つかりません。")
    else:
        messagebox.showerror("エラー", "ゲームが選択されていません。")

def show_context_menu(event):
    context_menu.post(event.x_root, event.y_root)

def toggle_dark_mode():
    if dark_mode.get():
        root.configure(bg="#333333")
        game_listbox.configure(bg="#333333", fg="#FFFFFF", selectbackground="#555555", selectforeground="#FFFFFF")
        context_menu.configure(bg="#333333", fg="#FFFFFF")
        for item in context_menu.winfo_children():
            item.configure(bg="#333333", fg="#FFFFFF")
        for button in button_frame.winfo_children():
            button.configure(bg="#444444", fg="#FFFFFF")
    else:
        root.configure(bg="#FFFFFF")
        game_listbox.configure(bg="#FFFFFF", fg="#000000", selectbackground="#CCCCCC", selectforeground="#000000")
        context_menu.configure(bg="#FFFFFF", fg="#000000")
        for item in context_menu.winfo_children():
            item.configure(bg="#FFFFFF", fg="#000000")
        for button in button_frame.winfo_children():
            button.configure(bg="#DDDDDD", fg="#000000")

def on_drag_start(event):
    global drag_data
    drag_data = {"index": game_listbox.nearest(event.y)}

def on_drag_motion(event):
    game_listbox.selection_clear(0, tk.END)
    game_listbox.selection_set(game_listbox.nearest(event.y))

def on_drag_drop(event):
    global drag_data
    drop_index = game_listbox.nearest(event.y)
    if drag_data["index"] != drop_index:
        games = load_games()
        keys = list(games.keys())
        keys.insert(drop_index, keys.pop(drag_data["index"]))
        sorted_games = {key: games[key] for key in keys}
        save_games(sorted_games)
        update_game_list()

def main():
    global game_listbox, context_menu, root, dark_mode, button_frame, drag_data

    drag_data = {}

    root = tk.Tk()
    root.title("ゲームランチャー")
    root.geometry("600x400")

    # ゲームリストの作成
    game_listbox = tk.Listbox(root)
    game_listbox.pack(expand=True, fill=tk.BOTH)
    game_listbox.bind("<Double-1>", launch_game)
    game_listbox.bind("<Button-3>", show_context_menu)
    game_listbox.bind("<Button-1>", on_drag_start)
    game_listbox.bind("<B1-Motion>", on_drag_motion)
    game_listbox.bind("<ButtonRelease-1>", on_drag_drop)

    # 右クリックメニューの作成
    context_menu = tk.Menu(root, tearoff=0)
    context_menu.add_command(label="ゲーム名を変更", command=change_game_name)
    context_menu.add_command(label="ゲームを削除", command=delete_game)
    context_menu.add_command(label="ファイルの場所を開く", command=open_file_location)
    context_menu.add_separator()
    dark_mode = tk.BooleanVar()
    context_menu.add_checkbutton(label="ダークモード", variable=dark_mode, command=toggle_dark_mode)

    # ボタンフレームの作成
    button_frame = tk.Frame(root)
    button_frame.pack(pady=5)

    # ボタンの作成と配置
    add_button = tk.Button(button_frame, text="ゲームを追加", command=add_game)
    add_button.pack(side=tk.LEFT, padx=5)

    # ゲームリストの更新
    update_game_list()

    root.mainloop()

if __name__ == "__main__":
    main()
