import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog
import subprocess
import os
import json

# データファイルのパス
DATA_FILE = 'games.json'

def load_games():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'r') as file:
            return json.load(file)
    return {}

def save_games(games):
    with open(DATA_FILE, 'w') as file:
        json.dump(games, file, indent=4)

def add_game():
    file_path = filedialog.askopenfilename(filetypes=[("Executable files", "*.exe")])
    if file_path:
        game_name = os.path.basename(file_path)
        games = load_games()
        if game_name in games:
            messagebox.showwarning("警告", "このゲームはすでにリストに存在します。")
        else:
            games[game_name] = file_path
            save_games(games)
            update_game_list()
            messagebox.showinfo("成功", "ゲームが追加されました。")

def launch_game():
    selected_game = game_listbox.get(tk.ACTIVE)
    if selected_game:
        games = load_games()
        game_path = games.get(selected_game)
        if game_path and os.path.exists(game_path):
            subprocess.Popen(game_path, shell=True)
        else:
            messagebox.showerror("エラー", "指定されたゲームの実行ファイルが見つかりません。")
    else:
        messagebox.showerror("エラー", "ゲームが選択されていません。")

def update_game_list():
    game_listbox.delete(0, tk.END)
    games = load_games()
    for game_name in games.keys():
        game_listbox.insert(tk.END, game_name)

def change_game_name():
    selected_game = game_listbox.get(tk.ACTIVE)
    if selected_game:
        new_name = simpledialog.askstring("ゲーム名変更", "新しいゲーム名を入力してください:")
        if new_name:
            games = load_games()
            if new_name in games:
                messagebox.showwarning("警告", "このゲーム名はすでにリストに存在します。")
            else:
                games[new_name] = games.pop(selected_game)
                save_games(games)
                update_game_list()
                messagebox.showinfo("成功", "ゲーム名が変更されました。")
    else:
        messagebox.showerror("エラー", "ゲームが選択されていません。")

def main():
    global game_listbox

    root = tk.Tk()
    root.title("ゲームランチャー")
    root.geometry("400x300")

    # ゲームリストの作成
    game_listbox = tk.Listbox(root)
    game_listbox.pack(expand=True, fill=tk.BOTH)

    # ボタンの作成
    add_button = tk.Button(root, text="ゲームを追加", command=add_game)
    add_button.pack(pady=5)

    launch_button = tk.Button(root, text="選択したゲームを起動", command=launch_game)
    launch_button.pack(pady=5)

    rename_button = tk.Button(root, text="ゲーム名を変更", command=change_game_name)
    rename_button.pack(pady=5)

    update_game_list()

    root.mainloop()

if __name__ == "__main__":
    main()
